Student ID: 104598854
Name: An Vo
Class: Intro to Operating Systems
Project: Lab2

!!! SORRY THIS IS LATE, I COULD NOT FIGURE OUT FOR THE LIFE OF ME HOW TO PRINT OUT THE SHELL INFO.
!!! GOT IT TO THE BEST STATE I COULD.

ORGANIZATION:
---main.cpp---
runs the whole program with no other files.

STATUS:
- Everything works and runs, getting commands to run and print takes a little. 
- FORSURE "ls --a" works (will provide screenshot).

SOFT/HARDWARE:
-Tested on:CSEGRID.

HOW TO COMPILE
- unZip file.
- Run Terminal.
- cd into unzipped file.
- run 'make' (without quotes)
- run './VoLab2' (without quotes)
